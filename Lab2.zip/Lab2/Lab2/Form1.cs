﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Main();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void Main()
        {
            XmlDocument xml = new XmlDocument();
            xml.Load(@"C:\Myfiles\XMLfile.xml");

            XmlElement element = xml.DocumentElement;

            foreach (XmlNode xnode in element)
            {
                if (xnode.Attributes.Count > 0)
                {
                    XmlNode date = xnode.Attributes.GetNamedItem("date");
                    XmlNode result = xnode.Attributes.GetNamedItem("result");

                    if (date != null && result != null)
                    {
                        listBox1.Items.Add($"Date: {date.Value}");
                        listBox1.Items.Add($"Result: {result.Value}");
                    }
                }

                foreach (XmlNode childnode in xnode.ChildNodes)
                {
                    if (childnode.Name == "ip-from")
                        listBox1.Items.Add($"Ip: {childnode.InnerText}");
                    if (childnode.Name == "method")
                        listBox1.Items.Add($"Method: {childnode.InnerText}");
                    if (childnode.Name == "url-to")
                        listBox1.Items.Add($"Url: {childnode.InnerText}");
                    if (childnode.Name == "response")
                        listBox1.Items.Add($"Response: {childnode.InnerText}");
                }
            }
        }

    }
}
