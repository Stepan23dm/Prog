﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace LABA2
{
    [XmlRoot("log")]
    public class Log
    {
        [XmlElement("event")]
        public List<Events> Items { get; set; }
    }
}
