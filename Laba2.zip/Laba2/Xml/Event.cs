﻿using System.Xml.Serialization;

namespace LABA2
{
    public class Events
    {
        //[XmlElement("addressee")]
        //public string Addressee { get; set; }
        [XmlAttribute]
        public string date { get; set; }

        [XmlAttribute]
        public string result { get; set; }

        [XmlElement("ip-form")]
        public string IP_From { get; set; }

        [XmlElement("method")]
        public string Method { get; set; }

        [XmlElement("url-to")]
        public string URL_To { get; set; }

        [XmlElement("response")]
        public string Response { get; set; }

        public override string ToString()
        {
            return $"{nameof(date)}:{date}; " +
                   $"{nameof(result)}:{result}; " +
                   $"{nameof(IP_From)}:{IP_From}; " +
                   $"{nameof(Method)}:{Method}; " +
                   $"{nameof(URL_To)}:{URL_To}; " +
                   $"{nameof(Response)}:{Response};";
        }
    }
}
