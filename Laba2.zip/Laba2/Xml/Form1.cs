﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace LABA2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //Address();

        }

        private IData data = new GetResult();

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                propertyGrid1.SelectedObject = listBox1.SelectedItem;
            }
        }

        public interface IData
        {
            List<Events> GetData();
        }

        public class GetResult : IData
        {
            public List<Events> GetData()
            {
                var serializer = new XmlSerializer(typeof(Log));
                var addressBookFromXml = new List<Events>();

                using (var reader = new FileStream("XMLfile.xml", FileMode.Open)) //@"C:\Myfiles\XMLfile.xml"
                {
                    addressBookFromXml = ((Log)serializer.Deserialize(reader)).Items;
                }

                return addressBookFromXml;
            }
        }

        private void propertyGrid1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (var address in data.GetData())
                {
                    listBox1.Items.Add(address);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"ValidatingReaderExample.Exception: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }
    }
}
