﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
           
            try
            {
                listBox1.Items.Clear();

                int startHours = Convert.ToInt32(textBox8.Text);
                int startMinutes = Convert.ToInt32(textBox7.Text);
                int startSecond = Convert.ToInt32(textBox6.Text);
                
                int hoursValue = Convert.ToInt32(textBox2.Text);
                int minutesValue = Convert.ToInt32(textBox3.Text);
                int secondsValue = Convert.ToInt32(textBox4.Text);

                int secondsValue1 = Convert.ToInt32(textBox1.Text);
                int dayValue = Convert.ToInt32(textBox5.Text);

                if ((startHours >= 0 && startHours <= 23) && (startMinutes >= 0 && startMinutes <= 59) && 
                    (startSecond >= 0 && startSecond <= 59) &&(hoursValue >= 0 && hoursValue <= 23) && 
                    (minutesValue >= 0 && minutesValue <= 59) && (secondsValue >= 0 && secondsValue <= 59) && 
                    (dayValue > 0) && (secondsValue1 > 0))
                {
                    Time time = new Time(startHours, startMinutes, startSecond);
                    var timeCnv = new TimeSpan(time.getHour(), time.getMin(), time.getSec());
                    
                    var t = TimeSpan.FromSeconds(Convert.ToDouble(textBox1.Text));
                    var day = TimeSpan.FromDays(Convert.ToDouble(textBox5.Text));
                    var secondTime = new TimeSpan(hoursValue, minutesValue, secondsValue);

                    TimeSpan ans = timeCnv.Add(t);
                    
                    TimeSpan minusDay = timeCnv.Subtract(day);
                    
                    TimeSpan objTime = timeCnv.Subtract(secondTime);
                   
                    if (checkBox1.Checked)
                    {
                        DateTime value1 = DateTime.Today.Add(ans);
                        DateTime value2 = DateTime.Today.Add(minusDay);
                        DateTime value3 = DateTime.Today.Add(objTime);
                        listBox1.Items.Add($"+количество секунд: {value1.ToString("hh:mm:ss tt")}");
                        listBox1.Items.Add($"-количество дней: {minusDay.ToString("dd")} {value2.ToString("hh:mm:ss tt")}");
                        listBox1.Items.Add($"-объект время: {value3.ToString("hh:mm:ss tt")}");

                        if (timeCnv == secondTime)
                        {
                            listBox1.Items.Add("True");
                        }
                        else
                        {
                            listBox1.Items.Add("False");
                        }


                        listBox1.Items.Add("/-------------/");
                    }
                    if (checkBox2.Checked)
                    {
                        listBox1.Items.Add($"+количество секунд: {ans}");
                        listBox1.Items.Add($"-количество дней: {minusDay}");
                        listBox1.Items.Add($"-объект время: {objTime}");
                        if (timeCnv == secondTime)
                        {
                            listBox1.Items.Add("True");
                        }
                        else
                        {
                            listBox1.Items.Add("False");
                        }

                    }
                    if (!checkBox1.Checked && !checkBox2.Checked)
                    {
                        MessageBox.Show("Сhoose a format!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Data entered incorrectly!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Validation error: {ex}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
                e.Handled = true;
        }

        private void textBox1_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
                e.Handled = true;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
                e.Handled = true;
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
                e.Handled = true;
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
                e.Handled = true;
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
                e.Handled = true;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
                e.Handled = true;
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
                e.Handled = true;
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
                e.Handled = true;
        }
    }
}
