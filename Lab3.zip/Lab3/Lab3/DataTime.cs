﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab3
{
    class Time
    {
        private int hours;

        private int minutes;

        private int seconds;

        public Time(int h, int m, int s)
        {
            this.hours = h;
            this.minutes = m;
            this.seconds = s;
        }

        public int getHour()
        {
            return hours;
        }

        public int getMin()
        {
            return minutes;
        }

        public int getSec()
        {
            return seconds;
        }
        
    }

}
