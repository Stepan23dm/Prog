﻿using System;

namespace Lab1_1
{
    class Matrix
    {
        static void Main()
        {
            int[,] m = new int[5, 5];
            int i, j;
            bool flag = true;
            Random rnd = new Random();

            //Ввод матрицы
            for (i = 0; i < 5; i++)
            {
                for (j = 0; j < 5; j++)
                {
                    //Рандомная матрица
                    //m[i, j] = rnd.Next(0, 10);
                    //Ручной ввод матрицы
                    Console.WriteLine("Введите a[{0},{1}]:", i, j);
                    m[i, j] = int.Parse(Console.ReadLine());
                }
            }

            //Проверка матрицы на симметричность
            for (i = 0; i < 5; i++)
            {
                for (j = 0; j < 5; j++)
                {
                    if (m[i, j] != m[j, i])
                    {
                        flag = false;
                    }
                }
            }
            if (flag)
            {
                Console.WriteLine("Данная матрица - симметрична");
            }
            else
            {
                Console.WriteLine("Данная матрица - не симметрична");
            }
            Console.WriteLine("Сгенерированная матрица:");

            //Вывод матрицы
            for (i = 0; i < 5; i++)
            {
                for (j = 0; j < 5; j++)
                {
                    Console.Write(m[i, j].ToString() + "\t");
                }
                Console.WriteLine();
            }
        }
    }
}

