﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laba1_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        //Конвертация из 10-ой в 2-ую систему счисления
        public class ConvertPart2
        {
            public string Getresult(string result, string right)
            {
                result += '.';

                int count = right.ToString().Count(); 
                int INTright = Convert.ToInt32(right);

                for (int i = 0; i < 5; i++)
                {
                    INTright = INTright * 2;
                    if (INTright.ToString().Count() > count)
                    {
                        string buf = INTright.ToString();
                        buf = buf.Remove(0, 1);
                        INTright = Convert.ToInt32(buf);

                        result += '1';
                    }
                    else
                    {
                        result += '0';
                    }
                }
                return result;
            }
        }
        public class ConvertPart1: ConvertPart2
        {
            public string GetValue(string num)
            {
                bool flag = true;
                string result = ""; 
                int left = 0; 
                string right = "0"; 
                string[] temp1 = num.Split(new char[] { '.', ',' }); 
                left = Convert.ToInt32(temp1[0]);

                if (left < 0)
                {
                    left *= -1;
                    flag = false;
                }

                if (temp1.Count() > 1)
                {
                    right = num.Split(new char[] { '.', ',' })[1]; 
                }
                while (true)
                {
                    result += left % 2; 
                    left = left / 2; 
                    if (left == 0)
                        break;
                }

                result = new string(result.ToCharArray().Reverse().ToArray());

                if (Convert.ToInt32(right) == 0)
                {
                    if (flag)
                    {
                        return result;
                    }
                    else
                    {
                        result = "-" + result;
                        return result;
                    }
                }
                else
                {
                    if (flag)
                    {
                        return Getresult(result, right);
                    }
                    else
                    {
                        string res = "-" + Convert.ToString(Getresult(result, right));
                        return res;
                    }
                    
                }
            }
        }

        //Конвертация из 2-ой в 10-ую систему счисления
        public class ConvertTo10_2
        {
            public string Get_Part2(string res1, string right)
            {
                res1 += ".";

                double res = 0;

                for (int i = 0; i < right.Length; i++)
                {
                    res += double.Parse(right[i].ToString()) * Math.Pow(2, (-1 - i));
                }

                string result = Convert.ToString(res).Replace("0,", "");

                res1 += result;

                return res1;
            }
        }

        public class ConvertTo10: ConvertTo10_2
        {
            public string Get_Result(string num)
            {
                int left;
                double res = 0;
                string right = "";
                string[] temp1 = num.Split(new char[] { '.', ',' });
                left = Convert.ToInt32(temp1[0]);

                if (temp1.Count() > 1)
                {
                    right = num.Split(new char[] { '.', ',' })[1];
                }

                if (left < 0)
                {
                    num = Convert.ToString(left * -1);
                    
                    for (int i = 0; i < num.Length; i++)
                    {
                        res += double.Parse(num[i].ToString()) * Math.Pow(2, (num.Length - 1) - i);
                    }

                    string res1 = "-" + Convert.ToString(res);

                    if (Convert.ToInt32(right) == 0)
                        return res1;
                    else
                        return Get_Part2(res1, right);

                } else
                {

                    num = Convert.ToString(left);

                    for (int i = 0; i < num.Length; i++)
                    {
                        res += double.Parse(num[i].ToString()) * Math.Pow(2, (num.Length - 1) - i);
                    }

                    string res1 = Convert.ToString(res);

                    if (Convert.ToInt32(right) == 0)
                        return res1;
                    else
                        return Get_Part2(res1, right);
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text.Length != 0)
                {
                    string number = Convert.ToString(textBox1.Text);

                    if (radioButton2.Checked)
                    {
                        var ConvertTo2 = new ConvertPart1();
                        string res = Convert.ToString(ConvertTo2.GetValue(number));
                        label5.Text = res;
                    }
                    else
                    {
                        if (Exam(number))
                        {
                            var ConvertTo10 = new ConvertTo10();
                            string res = Convert.ToString(ConvertTo10.Get_Result(number));

                            label5.Text = Convert.ToString(res);
                        }
                        else
                        {
                            MessageBox.Show("A binary number can only contain the digits 0 and 1!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        
                    }
                }else
                {
                    MessageBox.Show("Enter the number!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }catch
            {
                MessageBox.Show("The data entered is incorrect!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        static bool Exam(string s)
        {
            Regex r = new Regex(@"[^2-9]");
            Match m = r.Match(s);
            int k = 0;
            while (m.Success)
            {
                k++;
                m = m.NextMatch();
            }
            int len = s.Length;
            if (len == k)
                return true;
            else
                return false;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != ',' && e.KeyChar != '-' && e.KeyChar != '.')
                e.Handled = true;
        }
    }
}
