﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laba1_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text.Length != 0)
                {
                    int number = Convert.ToInt32(textBox1.Text);
                    if (radioButton2.Checked)
                    {
                        int temp1 = 0;
                        List<int> result = new List<int>();
                        while (number > 0)
                        {
                            temp1 = number % 2;
                            number = number / 2;
                            result.Add(temp1);
                        }
                        result.Reverse();

                        string res = string.Join("", result);
                        MessageBox.Show(res);
                    }
                    else
                    {
                        ulong num = 0, ost = 0, result_2 = 0, count = 0, s = 0;
                        num = ulong.Parse(textBox1.Text);
                        while (num > 0)
                        {
                            ost = num % 10;
                            s = Convert.ToUInt64(Math.Pow(2, count));
                            result_2 = result_2 + ost * s;
                            count += 1;
                            num = num / 10;

                        }

                        MessageBox.Show(Convert.ToString(result_2));
                    }
                }else
                {
                    MessageBox.Show("Enter the number!");
                }
            }catch (InvalidCastException ex){
                MessageBox.Show("Error!" + ex);
            }

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8) 
            {
                e.Handled = true;
            }
        }
    }
}
