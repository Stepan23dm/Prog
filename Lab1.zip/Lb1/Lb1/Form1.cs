﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lb1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            dataGridView1.RowCount = 6;
            dataGridView1.ColumnCount = 5;
            dataGridView1.AllowUserToAddRows = false;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                bool empty = false;

                double[,] matrix = new double[5, 5];

                for (int row = 0; row < dataGridView1.Rows.Count; row++)
                {
                    for (int columns = 0; columns < dataGridView1.Columns.Count; columns++)
                    {
                        if (dataGridView1[row, columns].Value == null)
                        {
                            empty = true;
                        }
                    }
                }

                if (empty == false)
                {
                    for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    {
                        for (int j = 0; j < dataGridView1.Columns.Count; j++)
                        {
                            matrix[i, j] = double.Parse(dataGridView1[i, j].Value.ToString());
                        }
                    }

                    bool flag = true;
                    Random rnd = new Random();

                    //Проверка матрицы на симметричность
                    for (int i = 0; i < 5; i++)
                    {
                        for (int j = 0; j < 5; j++)
                        {
                            if (matrix[i, j] != matrix[j, i])
                            {
                                flag = false;
                            }
                        }
                    }
                    if (flag)
                    {
                        MessageBox.Show("Данная матрица - симметрична");

                    }
                    else
                    {
                        MessageBox.Show("Данная матрица - не симметрична");
                    }

                }
                else
                {
                    MessageBox.Show("Enter the number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch 
            {
                MessageBox.Show("Unknown error.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            Random rnd = new Random();

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                for (int j = 0; j < dataGridView1.Columns.Count; j++)
                {
                    dataGridView1[i, j].Value = rnd.Next(100);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool empty = false;

            for (int row = 0; row < dataGridView1.Rows.Count; row++)
            {
                for (int columns = 0; columns < dataGridView1.Columns.Count; columns++)
                {
                    if (dataGridView1[row, columns].Value == null)
                    {
                        empty = true;
                    }
                }
            }
            if (empty == false)
            {
                dataGridView1.Rows.Clear();
                dataGridView1.Columns.Clear();

                dataGridView1.RowCount = 5;
                dataGridView1.ColumnCount = 5;
            }
        }

        private void dataGridView1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != ',' && e.KeyChar != '-')
                e.Handled = true;
        }

        private void dataGridView1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            switch (dataGridView1.CurrentCell.ColumnIndex)
            {
                case 0:
                    e.Control.KeyPress -= new KeyPressEventHandler(dataGridView1_KeyPress);
                    e.Control.KeyPress += new KeyPressEventHandler(dataGridView1_KeyPress);
                    break;
                case 1:
                    e.Control.KeyPress -= new KeyPressEventHandler(dataGridView1_KeyPress);
                    e.Control.KeyPress += new KeyPressEventHandler(dataGridView1_KeyPress);
                    break;
                case 2:
                    e.Control.KeyPress -= new KeyPressEventHandler(dataGridView1_KeyPress);
                    e.Control.KeyPress += new KeyPressEventHandler(dataGridView1_KeyPress);
                    break;
                case 3:
                    e.Control.KeyPress -= new KeyPressEventHandler(dataGridView1_KeyPress);
                    e.Control.KeyPress += new KeyPressEventHandler(dataGridView1_KeyPress);
                    break;
                case 4:
                    e.Control.KeyPress -= new KeyPressEventHandler(dataGridView1_KeyPress);
                    e.Control.KeyPress += new KeyPressEventHandler(dataGridView1_KeyPress);
                    break;
            }
        }
    }
}
